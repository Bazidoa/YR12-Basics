function whileom(){
//Elöl tesztelő ciklus
var i = 0;
while(i<10){
    console.log("Elöl tesztelem: " + i);
    i++;
}
}

function dowhile(){
//Hátul tesztelő ciklus
var i = 0;
do {
    console.log("Hátul tesztelem " + i);
    i++;
}while(i<10);
}
