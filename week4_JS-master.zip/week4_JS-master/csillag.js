'use strict';

function csillag_if(){

var s='';
for (var i= 1; i<16; i++){
  s = s + '*';
  if (i%5===0){
    s = s + "\n";
  }

}  console.log(s);
    console.log("Done");
}


function csillag5x5(){
var rajz='';
for (var i=0; i<3; i++){ 
    for (var j=0; j<5; j++){
        rajz=rajz+'*';      
    }
    rajz=rajz+'\n';
} 
console.log(rajz);
console.log("Done2");
} 

function fenyofaRajzolo(height){
var height=5;
  var fenyofa = "";
  //ciklusváltozó létrehozása,ciklusvezérlő feltételének megadása, ciklusváltózó váloztatása
  for (var i=0; i<height; i++ ){
    for (var j=0; j<i+1; j++ ){
      fenyofa += "*"; // fenyofa = fenyofa + "*";
    }
  fenyofa += "\n";  
  }
  console.log(fenyofa);
  //miért nem lehet előbb return aztán logolni?
  return(fenyofa);
}

function zaszlocska(){
/*height darabú sorom lesz, majd a oszlopok számát úgy határozom meg, hogy 
a belső ciklus add fut amíg a számlálója kisebb mint a külső ciklus abszolút értéke - a magasság fele 
*/

  var height = 7;
  var fenyofa ="";
  var szelesseg = parseInt (prompt ("Milyen széles legyen a zászló?"));
  for (var i=0; i<height; i++){
    for(var j=0; j<Math.abs(i-Math.floor(height/2))+szelesseg; j++){
      fenyofa+="*";
    }
    fenyofa += "\n";
  }
  console.log(fenyofa);
  return(fenyofa);
}