function contim(){
    var arr = [1,2,3,4,5,6,7,8,9,10];

    for (var i = 0; i < arr.length; i++){
        if (arr[i]%2===0){
            continue;
        }
        console.log(arr[i]);
    }

console.log("BREAAAAAAK");


   var num=0;
    while (num<arr.length-1){
        
        if (arr[num]%2==0){
            num++; 
            continue; 
        }
         
        console.log(arr[num]);  
        
    }
   
    console.log("BREAAAAAAK2");
   
    var num2=0;
    do{
        if (arr[num2]%2==0){
        num2+=1;
        continue;
        
    }
    console.log(arr[num2]);
    num2 +=1;
    
    
} while (num2<arr.length);

}
