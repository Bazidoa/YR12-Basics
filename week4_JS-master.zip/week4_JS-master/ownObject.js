'use strict'

function Auto(mark,tipu, teljesitmeny, color){

    this.marka=mark;
    this.tipus=tipu;
    this.telj=teljesitmeny;
    this.szin=color;
    this.currentPositionX=0;
    this.currentPositionY = 0;
    this.currentPosition3D = new Point3D(0, 0, 0);
    this.currentRendszam = new Rendszam ("aaa",111);
    //a new operátor azért kell mert TÍPUS és nem function és abból készítek egy új példányt. 

    this.Move = function (deltaX, deltaY) {
        this.currentPositionX += deltaX;
        this.currentPositionY += deltaY;
    }
    this.Move2 = function (newPosition) {
        this.currentPosition3D = newPosition;
    }

    this.RendszamGen = function (newRendszam){
        this.currentRendszam = newRendszam;
    }
    
}

function Point3D (x,y,z){

    this.x=x;
    this.y=y;
    this.z=z;

}

function Rendszam (szoveg, szam){
    this.szoveg=szoveg;
    this.szam=szam;
}



var imiAutoja = new Auto("opel", "ASTRA", 112, "holdezüst");

var oliAutoja = new Auto("ford", "MONDEO", 200,"piros");
//oliAutoja.szin="pink";

var adamAutoja = new Auto("volvo", "c30", 120, "narancssárga");

var bertiAutoja = new Auto("trabant", "kombi", 26, "zöld");

var autok=[
    imiAutoja, 
    oliAutoja, 
    adamAutoja, 
    bertiAutoja,
];

for (var i = 0; i<autok.length; i++){
    console.log(autok[i]);
}
imiAutoja.Move(20,40);
oliAutoja.Move(30,1);

adamAutoja.Move2(new Point3D(20,30,40));
console.log(adamAutoja);

bertiAutoja.RendszamGen( new Rendszam("abc",456));
console.log(bertiAutoja);

for (var i = 0; i<autok.length; i++){
    console.log(autok[i]);
}

var p1 = new Point3D(10,20,30);
var p2;
var s = "";

console.log("objektum vagyok: ");
console.log(p1);

console.log("üres string vagyok: ");
console.log(s);

s = JSON.stringify(p1);
console.log("string vagyok: "+s);

console.log("még nem vagyok semmi: ")
console.log(p2);
p2 = JSON.parse(s);

console.log("objektum lettem: ");
console.log(p2);

console.log(imiAutoja);
var p3 = JSON.stringify(imiAutoja);
console.log(p3);
