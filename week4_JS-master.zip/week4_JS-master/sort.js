function sort(){

var arrStrings = ["banana", "apple", "kiwi", "mango", "grape", "lemon","DRAGON", "bear", "apricot", "mandarin", 10];
var arrNumber = [6,3,7,9,3,55,7,33,0,1,45,7,99,7];

console.log(arrStrings);
arrStrings.sort();
console.log(arrStrings);

console.log(arrNumber);
arrNumber.sort();
console.log(arrNumber);

function ascNumbers(a, b){
    return a-b;
}

function descNumbers(a, b){
    return -1*(a-b);
}

function DescStrings(s1, s2){
    var result;
    if (s1==s2){
        result=0;
    } else if (s1<s2){
        result=1;
    } else {
        result=-1;
    }
    return result;
}

arrNumber.sort(ascNumbers); //NEM kell ()-t tenni a függvény végére, mert nem MEGHÍVOM csak ÁTADOM, majd jelen esetben a sort() odateszi.
console.log("növekvőben: ");
console.log(arrNumber);

arrNumber.sort(descNumbers);
console.log("csökkenőben: ");
console.log(arrNumber);


arrStrings.sort(DescStrings);
console.log(arrStrings);

arrStrings.reverse();
console.log(arrStrings);

}

