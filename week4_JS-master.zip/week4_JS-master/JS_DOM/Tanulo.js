'use strict';

function Diak(Neve, Eletkor, FotoURL, SzemelyiSzamElsoKaraktere) {
    this.Neve = Neve;
    this.Eletkor = Eletkor;
    this.FotoURL = FotoURL;
    this.SzemelyiSzamElsoKaraktere = SzemelyiSzamElsoKaraktere;

    this.getGender = function () {

        var result = '';

        if (this.SzemelyiSzamElsoKaraktere % 2 == 1) {
            var result = 'Valószínűleg fiú vagy';
        } else {
            var result = 'Valószínűleg lány vagy';
        }
        return result;
    }

}