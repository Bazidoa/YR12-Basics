'use strict'
////-------------------------------------------------- III/3. START --------------------------------------------------
//http://yellowroad.training360.com:3333/practice/basic/week3/12_loops_forin

var players = [{ name: "Barnabás Bese", bio: "Originally a right winger or striker, he developed…17s. Yet to make his senior breakthrough, though.", photo_done: "yes", position: "Defender", goals: 10, caps: 55 },
{ name: "Attila Fiola", bio: "Recently played as a centre-back for Puskas Academ…If all goes well, maybe my dream will come true.”", photo_done: "yes", position: "Defender", goals: 10 },
{ name: "Richárd Guzmics", bio: "Was ridiculed after a 2014 World Cup qualifier aga…ecome one of the most reliable defensive options.", photo_done: "yes", position: "Defender", goals: 10 },
{ name: "Tamás Kádár", bio: "Attack-minded left back who spent four years at Ne…is first senior international appearance in 2010.", photo_done: "yes", position: "Defender", goals: 10 },
{ name: "Mihály Korhut", bio: "In the squad to provide a reliable left-back back-…. Made his Hungary debut in 2014 against Denmark.", photo_done: "yes", position: "Defender", goals: 10, caps: 55 },
{ name: "Roland Juhász", bio: "Started his career as a striker, only to end up as…date equipment to Hungarian paediatric hospitals.", photo_done: "yes", position: "Defender", goals: 10, caps: 55 },
{ name: "Ádám Lang", bio: "Quick, strong and reliable, but struggles with car…r in 2015, and won his first Hungary cap in 2014.", photo_done: "yes", position: "Defender", goals: 10 },
{ name: "Ákos Elek", bio: "Tireless defensive midfielder who returned to the …s won 38 caps since his first appearance in 2010.", photo_done: "yes", position: "Midfielder", goals: 10, caps: 55 },
{ name: "Zoltán Gera", bio: "Attacking midfielder who spent ten years with West…hen made a quick comeback when Koeman was sacked.", photo_done: "yes", position: "Midfielder", goals: 10 },
{ name: "Tamás Priskin", bio: "Played for six different English clubs, starting a…e March, setting back his tournament preparation.", photo_done: "yes", position: "Forward", goals: 10, caps: 55 }
]

var allGoals = 0;

for (var k in players) {
    if (players[k].goals > 0) {
        players[k].ball = "/img/ball.png";
        if (players[k].caps > 50) {
            players[k].veteran = true;

        }
        allGoals += parseInt(players[k].goals);
        console.log(allGoals);
    }
}
console.log(players);
//--------------------------------------------------  III/3. END --------------------------------------------------

//-------------------------------------------------- III/5. START --------------------------------------------------

// 0th excercise
//http://yellowroad.training360.com:3333/practice/basic/week3/13_loops_while
var Ghosts = []; // ez csak azért kell, hogy a többi lefusson, amúgy a weboldalra nem
var i = 0;
while (i < 5) {
    var ghost = {
        actorID: "actor" + i,
        turnStart: 1,
        type: i + 1,
        startDelay: i * 2000

    }
    Ghosts.push(ghost);
    i++
}
// end of 0th excercise

// first excersize

/*
 Egy kisvárosban megfigyelték, hogy a város lakosainak száma minden évben 3 %-kal nő. 
2017-ben a lakosok száma 10.000. 
Számold ki, hogy ha ez a trend folytatódna, akkor mikorra érné el a lakosok száma a 20.000-et! 
Jelenítsd meg a kapott évet egy felugró ablakban!
*/

var evszam = 2017;
var lakosok = 10000;

while (lakosok < 20000) {
    lakosok = lakosok * 1.03;
    evszam += 1;
} console.log(evszam);

// end of first excercise

// second excersize

/*
Egy kamaszfiú szülei X Ft zsebpénzt adtak a fiuknak.
A fiú 500 Ft-ot költött az első napon, majd minden rákövetkező napon 100 Ft-tal többet, mint az előző nap. 
Számold ki, hogy ha így folytatja, akkor hány napig tud így költekezni, és mennyi pénze marad! 
Jelenítsd meg a kapott eredményt egy felugró ablakban!
*/

var zsebpenz = 10000;
var nap = 1;
var koltes = 500;

while (zsebpenz > 0) {
    zsebpenz = zsebpenz - koltes;
    koltes += 100;
    nap += 1
    if (koltes > zsebpenz) {
        break;
    }
} console.log("Ebben a tempóban " + nap + " nap alatt el fog fogyni a pénzed és ennyid maradt: " + zsebpenz);


// end of second excersize

// third excercise

/*
Írj egy teszt programot, amiben egy kérdést teszel fel mindaddig, amíg meg nem kapod a helyes választ
Most használd a prompt metódust a bekéréshez!
*/

var answer = prompt("Hány lába van a póknak?");
while (true) {
    var talalt = false;
    switch (answer) {
        // a prompt visszatérési értéke String! ezért a számot is  " "-be kell tenni. A parseInt bezavarna a "nyolc"-nál
        case "8":
            talalt = true;
            break;

        case "nyolc":
            talalt = true;
            break;
    }
    if (talalt == true) {
        break;
    }
    answer = prompt(talalt + "Na ne szivass, hány lába van a póknak?");
}
console.log("Grat te majom");

// end of third excercise

//--------------------------------------------------  III/5. END --------------------------------------------------

//--------------------------------------------------  III/7. START --------------------------------------------------

// first excercise 

/*
Az értékesítők 10% jutalékot kapnak, de csak abban az esetben, ha a havi eladás értéke legalább 1.000.000 Ft.
Számold ki, a jutalékot a bekért eladási összeg alapján és jelenítsd meg a kapott értéket egy felugró ablakban!
*/

var eladasiOsszeg = prompt("Mennyit adtál el az első hónapban?");
var haviJutalek = "Sajnos a hónapban nem érted el az 1.000.000 Ft-t eladást.";
if (eladasiOsszeg >= 1000000) {
    var haviJutalek = eladasiOsszeg * 0.1;
}
console.log(haviJutalek);

// end of first excercise

// second excercise

/*
Az értékesítők 10% jutalékot kapnak, ha a havi eladás értéke legalább 1.000.000 Ft. Különben ha az eladás elérte az 500.000 Ft-ot, akkor 5%. Azalatt nincs bónusz egyáltalán.
Számold ki a jutalékot a bekért eladási összeg alapján, és jelenítsd meg a kapott értéket egy felugró ablakban!
*/

var eladasiOsszeg = prompt("Mennyit adtál el a második hónapban?");
var haviJutalek = "Sajnos a hónapban nem érted el még az 500.000 Ft-ot sem.";
if (eladasiOsszeg >= 100000) {
    var haviJutalek = "Gratulálok, a bónuszod: " + eladasiOsszeg * 0.1 + " Ft";
} else if (eladasiOsszeg >= 500000) {
    var haviJutalek = "Gratulálok, a bónuszod: " + eladasiOsszeg * 0.05 + " Ft";
}
console.log(haviJutalek);

// end of second excercise

// third excercise

/*
Kérd be a villanyóra előző és jelenlegi állását! Ez alapján számítsd ki az aktuális havi számla összegét, ha egy egység 37.5 Ft!
A villanyóra állása egy egész szám 0 és 9999 között. Amikor a villanyóra eléri a 9999-et átfordul és újraindul 0-ról.
Ebben az esetben az előző állás nagyobb, mint az aktuális.
Jelenítsd meg az aktuális havi villanyszámla összegét, de ne felejtsd el előtte a 27% ÁFÁ-t hozzáadni!


*/

var elozoHavi = prompt("Mi a múlthavi állás?");
var eHavi = prompt("Mi az ehavi állás?");

var elozoHavi = parseInt(elozoHavi);
var eHavi = parseInt(eHavi);

var egyseg = 37.5;

if (eHavi < elozoHavi) {
    var kul = (Math.abs(eHavi) + 1 + (9999 - elozoHavi));
    var szamla = kul * egyseg;
} else {
    var kul = (eHavi - elozoHavi);
    var szamla = kul * egyseg;
}
console.log("A havi fogyasztásod: " + kul);
console.log(szamla * 1.27 + " Ft-ot kell fizetned öcsém");

// end of third excercise

//--------------------------------------------------  III/7. END --------------------------------------------------

//--------------------------------------------------  III/9. START --------------------------------------------------

// start of 0th excercise
//beépített gyakoroló a pacmanhez - ebbe még kell egy switch 
var i = 0;
while (i < 5) {
    var ghost = {
        actorID: "actor" + i,
        startDelay: i * 2000,
        type: i + 1,
        turnStart: 1
    }
    i++;
    Ghosts.push(ghost);
}
/*

switch (currentEated) {
    case 50:
        GhostSpeed += 50;
        continue;
    case 100:
        GhostSpeed += 50;
        continue;
    case 150:
        GhostSpeed += 50;
        continue;
    case 200:
        GhostSpeed += 50;
        continue;
    case 250:
        GhostSpeed += 50;
        break;
}*/

// end of beépített gyakorló

//start of first excercise

/*
Készíts egy lenyíló listát a hónapok neveivel! 
Gomb megnyomására írd ki, hogy a kiválasztott hónapban hány nap van! Használj switch utasítást!
*/


window.addEventListener('load',NapszamGenerator,false);

function NapszamGenerator(){
    console.log("MEHET A MENET KICCSÁVÓ");

    var nodeUtso = document.querySelector('#utsoDIV'); //QuerySelectorAll mindig tömböt ad vissza
    console.log(nodeUtso);
    var ListofMonths = document.createElement('SELECT');
    ListofMonths.setAttribute("id","HONAPSELECT")
    nodeUtso.appendChild(ListofMonths);
   
    var lista = document.querySelector('SELECT');
    var honapok = ["Jan","Feb","Marc", "Apr", "May","June","July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    for (i =0; i<12; i++){        
        var newOpt = document.createElement("OPTION");
        newOpt.innerText=honapok[i];
        lista.appendChild(newOpt);
    }
}

function napszam(){
    var napdb=30;
    var valasztottHonap = document.getElementById("HONAPSELECT").value;
    switch (valasztottHonap){
        case 'Jan':
        case 'Marc':
        case 'May':
        case 'July':
        case "Aug":
        case 'Oct':
        case 'Dec':
        napdb=31;
        break;
        case 'Feb':
        napdb=29;
        ;
        break;
    }
    console.log(valasztottHonap + napdb + "-ból áll");

   // console.log(valasztottHonap);
}
