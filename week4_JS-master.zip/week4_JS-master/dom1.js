'use strict';



var nodefirstPnl;
var nodesecondPnl;
var nodesRedSqr;
var nodesDivTags;

window.addEventListener('load', window_load_Handler, false); // window objektum load eseményét várjuj meg minden esetben, utána manipuláljunk, igen a get is manipulálás

function window_load_Handler() { //99.9%-ban a handlereknek nincs visszatérési értéke
    console.log("LETSGOOO");

    //nodegetterFuggvenyek();

    //nodequeryFuggvenyek();

    nodeModification();

    nodeCreation();

   nodeDeletion();
}

function nodequeryFuggvenyek() { //lekérdezést fogunk írni
    nodefirstPnl = document.querySelector('#firstPnl'); //returns the first "matching" element, if u want all use: 'querySelectorAll';
    console.log("first NODE: ")
    console.log(nodefirstPnl);

    nodesecondPnl = document.querySelector('#secondPnl'); //függvényen belül lehet megegyező változónév másik válozóval
    console.log("second NODE: ")
    console.log(nodesecondPnl);

    nodesRedSqr = document.querySelectorAll('.RedSqr');
    console.log(nodesRedSqr);
    for (var i = 0; i < nodesRedSqr.length; i++) {
        console.log(nodesRedSqr[i]);
        console.log(nodesRedSqr[i].getAttribute('class'));
    }

    var spanNodes = document.querySelectorAll('span');
    for (var i = 0; i < spanNodes.length; i++) {
        console.warn(spanNodes[i]);
        console.warn(spanNodes[i].innerText);
    }


}

function nodeModification() {
    var nodeAlfaSpan = document.querySelector('SPAN:first-child');
    console.log("inner text")
    console.log(nodeAlfaSpan);
    //nodeAlfaSpan.innerText = "almafa";
    nodeAlfaSpan.setAttribute('class', 'BlueSqr')
    nodeAlfaSpan.innerHTML = '<b>alma</b>fa';

}

function nodegetterFuggvenyek() {


    nodesecondPnl = document.getElementById("secondPnl");
    console.log(nodesecondPnl);

    nodefirstPnl = document.getElementById("firstPnl");
    console.log(nodefirstPnl);

    nodesRedSqr = document.getElementsByClassName("RedSqr");
    console.log(nodesRedSqr);
    for (var i = 0; i < nodesRedSqr.length; i++) {
        console.log(nodesRedSqr[i].getAttribute('class'));
    }

    nodesDivTags = document.getElementsByTagName("div");
    console.log("Írd ki az összes divet: ")
    for (var i = 0; i < nodesDivTags.length; i++) {
        console.log(nodesDivTags[i]);
        console.log(nodesDivTags[i].innerText);
    }
    console.log("Most csak a második divet írd ki: ")
    console.log(nodesDivTags[1]);

}

function nodeCreation() {
    var nodeElsoDiv = document.querySelector('#firstPnl');
    var nodeDeltaSpan = document.createElement('SPAN');
    nodeDeltaSpan.innerText = "Delta";
    nodeDeltaSpan.setAttribute("class","BlueSqr");
    nodeDeltaSpan.setAttribute("style","border: 3px solid yellow; padding: 5px");


    nodeElsoDiv.appendChild(nodeDeltaSpan);

    //hozzunk létre egy gammát
    var nodeMasodikDiv = document.querySelector('#secondPnl');
    var nodeHEloBelo = document.createElement('H2');
    nodeHEloBelo.innerText = "HELOBELO";

    nodeMasodikDiv.appendChild(nodeHEloBelo);

}

function nodeDeletion(){
    var nodeElsoDiv = document.querySelector('#firstPnl');
    var nodeBetaSpan = nodeElsoDiv.querySelector('SPAN:nth-child(2)');
    nodeElsoDiv.removeChild(nodeBetaSpan);
}

