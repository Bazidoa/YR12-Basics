'use strict';
var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "zöld"]
function arrindex() {
    var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "zöld"]
    

    console.log(arr.indexOf(6));
    console.log(arr.indexOf("zöld"));
    console.log(arr.indexOf(0));

    arr.push("kék");
    console.log(arr);

    //a tömb elejére teszek egy elemet
    arr.unshift(0);
    console.log(arr);

    //végéről leszedek egy elemet
    arr.pop();
    console.log(arr);

    arr.shift();
    console.log(arr);

    arr.splice(5, 4);
    console.log(arr);

}


function szam10() {
    var arr2 = [];
    for (var i = 100; i < 120; i++) {
        if (i % 2 == 1) {
            arr2.push(i);
        }
    }
    console.log(arr2);
    var arr3 = arr.concat(arr2);
    console.log("Hármas: " + arr3);

}

// tömb rendezése, saját algoritmus
/* 
végig kell iterálni a tömbön, és összehasonlítani balról jobbra párosával az elemeket. 
ha a kisebb indexű nagyobb mint a nagyobb indexű, a két számot kicserélem
kell két iteráló változó és egy átmentei tároló a cserékhez
*/
function sorrendezo(){
var i = 0;
var i2 = 1;
var ideiglenes;

var arr4 = [3,2,1];
console.log(arr4);
for (i=0; i<arr4.length;i++){
    if (arr4[i] > arr[i2]){
        ideiglenes = arr4[i];
        arr4[i]=arr4[i2];
        arr4[i2]=ideiglenes;
    }
    i2++;
} console.log(arr4);
}