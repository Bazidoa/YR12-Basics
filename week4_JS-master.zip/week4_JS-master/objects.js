'use strict'

function Person(cm,weight,name,age,gender){
    this.height = cm; //ezek a tulajdonságok //paraméter egyenlő 
    this.weight = weight;
    this.name = name;
    this.age = age;
    this.gender = gender;

    this.weightLoss = function( deltaWeight){
        this.weight -= deltaWeight;
    } 
    this.print = function(){
        return adam.age+adam.name;
    }

}

var adam = new Person(180,80,"Ádám",27, 1);

console.warn(adam.height+"ASDASD");

for (var k in adam){
    if (adam[k]instanceof Function){
        continue;
    }
    console.log(k);
    console.log(adam[k]);
    }
adam.weightLoss(9);

for (var k in adam){
    if (adam[k]instanceof Function){
        continue;
    }
    console.log(k);
    console.log(adam[k]);
    
}
alert(adam.print());
console.log(adam.print);
