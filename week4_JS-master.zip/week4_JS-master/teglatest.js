'use strict'

function teglatestTerfogat(aoldal,boldal,coldal){

/* KIPRÓBÁLTAM H MI TÖRTÉNIK HA EGY FÜGGVÉNYT AKAROK PÉLDÁNYOSÍTANI - MIVEL A FUNCTION SZINTAKTIKÁJA EGYFORMA
    this.a=aoldal;
    this.b=boldal;
    this.c=coldal;

*/
    return "Az " + this.a + "*" + this.b + "*" + this.c + " téglalatest térfogata: " + aoldal*boldal*coldal;
}
/*
var proba = teglatestTerfogat(5,10,15);

function fx(){
    var d = new Date();
}

console.log(proba);
*/