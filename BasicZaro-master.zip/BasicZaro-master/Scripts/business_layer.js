"use strict";


var anonymResults = [];

var Results = [];

loadDataFromJSON();
makeItResult(anonymResults);

function loadDataFromJSON() {
    anonymResults = JSON.parse(jsonDatastore2)
}


function makeItResult(Objektumok) {

    for (var i = 0; i < Objektumok.length; i++) {
       var newResult = new Result(Objektumok[i].Name, Objektumok[i].Subject, Objektumok[i].Mark, Objektumok[i].Date);
        Results.push(newResult);
    }
    console.log(Results);
}






































/* CSAK A JSON ÁLLOMÁNY ELKÉSZÍTÉSÉHEZ KELLETT -start

var Names = ["Adam","Bob","Claire","David"];

var Subjects = ["CSS","HTML","JavaScript","SQL","C#","Git"];

var Marks = [1,2,3,4,5];

var Dates = [];

var notAnonnymObjects = [];

function DataBaseInit(){
    // generálok egy objektumokat tartalmazó tömböt, amit majd JSON-né strigifyolok. az lesz a Fake DataBase




    for (var i = 0; i<100; i++){
       var Datum = new Date(2018,8,30+Math.floor(Math.random()*182));
    var szepDatum=Datum.getFullYear()+"-"+ (addZero(Datum.getMonth()+1))+"-"+ addZero(Datum.getDate());
    Dates.push(szepDatum);
    }
    console.log(Dates);

    function addZero(num){
        return num < 10 ? "0"+num : num;  //ha igaz akkor : előtti rész, ha hamis, kettőspont utáni rész
    }

    var Objektumok =[];

    for (var i = 0; i < 100; i++) {
        var newResult = {};
        newResult.Name = Names[Math.floor(Math.random()*Names.length)];
        newResult.Subject = Subjects[Math.floor(Math.random()*Subjects.length)];
        newResult.Mark = Marks[Math.floor(Math.random()*Marks.length)];
        newResult.Date=Dates[Math.floor(Math.random()*Dates.length)];
        Objektumok.push(newResult);
    }


    console.log(Objektumok);

    for (var i =0; i<Objektumok.length;i++){
        newResult = new Result (Objektumok[i].Name,Objektumok[i].Subject,Objektumok[i].Mark,Objektumok[i].Date);
        notAnonnymObjects.push(newResult);
    }

    console.log(notAnonnymObjects);


}

DataBaseInit();

var myJSON = JSON.stringify(notAnonnymObjects);
console.log(myJSON);

 CSAK A JSON ÁLLOMÁNY ELKÉSZÍTÉSÉHEZ KELLETT -end */