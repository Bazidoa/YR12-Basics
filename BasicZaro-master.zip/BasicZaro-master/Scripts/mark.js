"use strict";

function Result(name,subject,mark,date){
    this.Name = name;
    this.Subject = subject;
    this.Mark = mark;
    this.Date = date;    
}

