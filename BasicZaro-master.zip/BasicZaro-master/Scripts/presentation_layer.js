"use strict";

window.addEventListener("load", window_load_handler, false);

function window_load_handler() {
    console.log("You can start messing around in the DOM tree mate");
}

var statisticsSelect = document.querySelector("#statisztikaSelect");

statisticsSelect.addEventListener("change", GetStatisticsValue, false);

var GenerateBtn = document.querySelector("#generateBtn");
GenerateBtn.addEventListener("click", generatebtn_click_handler, false);

var PrintBtn = document.querySelector("#PrintBtn");
PrintBtn.addEventListener("click",myPrint,false);

var StatisticFilters = [];

var Subjects = ["HTML", "CSS", "Git", "JavaScript", "SQL", "C#"];

var Names = ["Adam", "Bob", "Claire", "David"];

var Averages = [];



DrawNaplo(Results);
DrawStatisticsOptions();

function DrawNaplo(objektumok) {

    var naploTableBody = document.querySelector("#naploTableBody");

    for (var i = 0; i < objektumok.length; i++) {
        var newTr = document.createElement("TR");
        for (var j = 0; j < Object.keys(objektumok[i]).length; j++) {
            var newTD = document.createElement("TD");
            var InnerText = Object.values(objektumok[i])[j];
            newTD.innerText = InnerText;
            newTr.appendChild(newTD);
        } naploTableBody.appendChild(newTr);
    }
}

function GetClassAverage(subject) {
    var sum = 0;
    var avg = 0;
    var counter = 0;
    for (var i = 0; i < Results.length; i++) {
        if (Results[i].Subject == subject) {
            sum += parseInt(Results[i].Mark);
            counter++;
        }
    } return avg = sum / counter;
}

//console.log(GetClassAverage("CSS"));


function DrawStatisticsOptions() {
    for (var i = 0; i < Results.length; i++) {
        if (StatisticFilters.includes(Results[i].Name)) {
            continue;
        }
        else {
            StatisticFilters.push(Results[i].Name);
            var newStatisticsOption = document.createElement("OPTION");
            var CategorySelect = document.querySelector("#studentGroupOpt");
            CategorySelect.appendChild(newStatisticsOption);
            newStatisticsOption.innerText = Results[i].Name;
            newStatisticsOption.setAttribute("data-statistics", Results[i].Name);
        }
    }
}



function CountAverage(name) {

    var HTMLSum = 0;
    var HTMLCount = 0;
    var HTMLAvg = 0;

    var CSSSum = 0;
    var CSSCount = 0;
    var CSSAvg = 0;


    var GitSum = 0;
    var GitCount = 0;
    var GitAvg = 0;

    var JavaScriptSum = 0;
    var JavaScriptCount = 0;
    var JavaScriptAvg = 0;

    var SQLSum = 0;
    var SQLCount = 0;
    var SQLAvg = 0;

    var CSharpSum = 0;
    var CSharpCount = 0;
    var CSharpAvg = 0;


    for (var i = 0; i < Results.length; i++) {
        if (Results[i].Name == name) {
            //console.log(Results[i].Subject, Results[i].Mark, Results[i].Name);
            switch (Results[i].Subject) {
                case "HTML":
                    HTMLSum += parseInt(Results[i].Mark);
                    HTMLCount++;
                    break;

                case "CSS":
                    CSSSum += parseInt(Results[i].Mark);
                    CSSCount++;
                    break;

                case "Git":
                    GitSum += parseInt(Results[i].Mark);
                    GitCount++;
                    break;

                case "JavaScript":
                    JavaScriptSum += parseInt(Results[i].Mark);
                    JavaScriptCount++;
                    break;

                case "SQL":
                    SQLSum += parseInt(Results[i].Mark);
                    SQLCount++;
                    break;

                case "C#":
                    CSharpSum += parseInt(Results[i].Mark);
                    CSharpCount++;
                    break;

            }
        }
    }
    Averages[0] = HTMLSum / HTMLCount;
    Averages[1] = CSSSum / CSSCount;
    Averages[2] = GitSum / GitCount;
    Averages[3] = JavaScriptSum / JavaScriptCount;
    Averages[4] = SQLSum / SQLCount;
    Averages[5] = CSharpSum / CSharpCount;

    console.log(Averages);


}

function GetStatisticsValue() {
    var statisticsOptionSelected = document.querySelector("#statisztikaSelect").value;
    //console.log(statisticsOptionSelected);
    EmptyStatTableBody();
    DrawStatistics(statisticsOptionSelected);

}

function DrawStatistics(filter) {

    if (filter == "Class") {
        console.log("Class");

        var CSS_sum = 0;
        var cssc = 0;

        var HTML_sum = 0;
        var htmlc = 0;

        var Js_sum = 0;
        var jsc = 0;

        var Git_sum = 0;
        var gitc = 0;

        var Csharp_sum = 0;
        var csharpc = 0;

        var SQL_sum = 0;
        var sqlc = 0;
        /*
                for (var i = 0; i < Results.length; i++){
                    if (Results[i].Subject == "CSS"){
                        CSS_sum += Results[i].Mark;
                        cssc++;
                    } else if
                }
        */
        for (var i = 0; i < Results.length; i++) {
            switch (Results[i].Subject) {
                case "HTML":
                    HTML_sum += parseInt(Results[i].Mark);
                    htmlc++;
                    break;

                case "CSS":
                    CSS_sum += parseInt(Results[i].Mark);
                    cssc++;
                    break;

                case "Git":
                    Git_sum += parseInt(Results[i].Mark);
                    gitc++;
                    break;

                case "JavaScript":
                    Js_sum += parseInt(Results[i].Mark);
                    jsc++;
                    break;

                case "SQL":
                    SQL_sum += parseInt(Results[i].Mark);
                    sqlc++;
                    break;

                case "C#":
                    Csharp_sum += parseInt(Results[i].Mark);
                    csharpc++;
                    break;
            }
        }

        Averages[0] = HTML_sum / htmlc;
        Averages[1] = CSS_sum / cssc;
        Averages[2] = Git_sum / gitc;
        Averages[3] = Js_sum / jsc;
        Averages[4] = SQL_sum / sqlc;
        Averages[5] = Csharp_sum / csharpc;
        var StatisticsTableBody = document.querySelector("#statisztikaTableBody");
        console.log(StatisticsTableBody);

        for (var i = 0; i < 6; i++) {
            var newTR = document.createElement("TR");
            var newSubjectTD = document.createElement("TD");
            newSubjectTD.innerText = Subjects[i];
            var newAtlagTD = document.createElement("TD");
            newAtlagTD.innerText = Averages[i];
            newTR.appendChild(newSubjectTD);
            newTR.appendChild(newAtlagTD);
            StatisticsTableBody.appendChild(newTR);
        }
    }
    else {

        CountAverage(filter);
        //a megkapott filternek (NÉV) megfelelő  Számolja meg az átlagokat -> call függvény
        var StatisticsTableBody = document.querySelector("#statisztikaTableBody");
        console.log(StatisticsTableBody);

        for (var i = 0; i < 6; i++) {
            var newTR = document.createElement("TR");
            var newSubjectTD = document.createElement("TD");
            newSubjectTD.innerText = Subjects[i];
            var newAtlagTD = document.createElement("TD");
            newAtlagTD.innerText = Math.round(Averages[i]);
            newTR.appendChild(newSubjectTD);
            newTR.appendChild(newAtlagTD);
            StatisticsTableBody.appendChild(newTR);

        }
    }

}

function EmptyStatTableBody() {
    var statTableBody = document.querySelector("#statisztikaTableBody");

    while (statTableBody.firstChild) {
        statTableBody.removeChild(statTableBody.firstChild);
    }
}

function generatebtn_click_handler() {
    var semesterresultDiv = document.querySelector("#ertesitoDiv");
    for (var i = 0; i < Names.length; i++) {

        CountAverage(Names[i]);

        var newSemesterResultTable = document.createElement("table");
        newSemesterResultTable.setAttribute("data-name", Names[i]);

        var newnameRow = document.createElement("TR");
        var newRow = document.createElement("TR");
        newSemesterResultTable.appendChild(newnameRow);

        var newnameTH = document.createElement("TH");
        newnameTH.setAttribute("colspan", 2);
        newnameTH.innerText = Names[i];
        newnameRow.appendChild(newnameTH);

        var newTH = document.createElement("TH");
        newTH.innerText = "Subject";
        var newTH2 = document.createElement("TH");
        newTH2.innerText = "Average";

        newRow.appendChild(newTH);
        newRow.appendChild(newTH2);
        newSemesterResultTable.appendChild(newRow);
        semesterresultDiv.appendChild(newSemesterResultTable);

        for (var j = 0; j < Subjects.length; j++) {


            var newTR = document.createElement("TR");
            var newSubjectTD = document.createElement("TD");
            newSubjectTD.innerText = Subjects[j];
            var newAtlagTD = document.createElement("TD");
            newAtlagTD.innerText = Math.round(Averages[j]);
            switch (newAtlagTD.innerText){
                case "2":
                newAtlagTD.innerText = "Elégséges ("+newAtlagTD.innerText+")";
                break;
                case "3":
                newAtlagTD.innerText = "Közepes ("+newAtlagTD.innerText+")";
                break;
                case "4":
                newAtlagTD.innerText = "Jó ("+newAtlagTD.innerText+")";
                break;
                case "5":
                newAtlagTD.innerText = "Jeles ("+newAtlagTD.innerText+")";
                break;
            
            }
            newTR.appendChild(newSubjectTD);
            newTR.appendChild(newAtlagTD);
            newSemesterResultTable.appendChild(newTR);
        }




    }
}
function myPrint(){
    window.print();
}