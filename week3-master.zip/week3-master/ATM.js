function penzFelvetel(){
/*A Szamlak nevű listán for-in ciklussal iterálok, a lista elemei objektumok. 
Megkeresem a beütött Számlaszámú objektumot és, ha van ennyi pénze, kiveszem, frissítem a rajta levő pénzt. 

FONTOS! ez most nem működik jól, csak az első objektumot kezeli -> for ciklussal menjünk végig a listán.

*/


var Szamlak=[
    {Szamlsz: 123, Balance: 1000000},
    {Szamlsz: 456, Balance: 100}
]

//a .value Stringet ad vissza, ezért kell a parseInt
var szamlaszam=parseInt(document.getElementById("Szamlsz").value);
var amount=parseInt(document.getElementById("penz").value);

console.log(szamlaszam);
console.log(amount);


var newBalance;
for ( var k in Szamlak){
   if ( (Szamlak[k].Szamlsz)==szamlaszam );
   console.log(Szamlak[k]);
    if (amount <=Szamlak[k].Balance){
        newBalance = Szamlak[k].Balance - amount;
        Szamlak[k].Balance=newBalance;
        break;
    } else {
        alert ("Vagy rosszul ütötted be a számlaszámod vagy nincs ennyi pénzed :(");
    }
} 
console.log("Az amount típusa: " + typeof amount);
console.log("A számlaszám típusa " + typeof szamlaszam);
console.log("Kivettél ennyi pénzt:" + amount);
console.log("Ennyi pénzed maradt:" + newBalance);
}
