function SzovegesErtekeles(erdemjegy){
    
    var SzErtekeles;

    switch(erdemjegy)
    {
        case 1:
            SzErtekeles = "elégtelen";
            break;
        case 2:
            SzErtekeles = "elégséges";
            break;
        case 3:
            SzErtekeles = "közepes";
            break;
        case 4:
            SzErtekeles = "jó";
            break;
        case 5:
            SzErtekeles = "jeles";
            break;
        default:
            SzErtekeles = "na ne szórakozz öcsém";
            break;
    }
    return SzErtekeles;

}