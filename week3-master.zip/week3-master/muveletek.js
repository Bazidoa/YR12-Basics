function Add (tag1, tag2){
    var a=document.getElementById("num1").value;
    var tag1 = parseInt(a);
    var b=document.getElementById("num2").value;
    var tag2 = parseInt(b);

    osszeg=tag1+tag2;
    console.log(osszeg);

}

function Sub(tag1, tag2){
    var a=document.getElementById("num1").value;
    var tag1 = parseInt(a);

    var b=document.getElementById("num2").value;
    var tag2 = parseInt(b);

    var kivonas=tag1-tag2;
    console.log(kivonas);
}

function Proba(tag1, tag2){
return tag1-tag2;
}

function Ker(A,B){
return (A+B)*2;
}