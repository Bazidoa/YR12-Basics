function szamolj(){
    var inputAmount = document.getElementById("penzed");
    var amount = parseInt(inputAmount.value);

    var kamatpercent=document.getElementById("kamat");
    var kamat = parseInt(kamatpercent.value);

    var years = document.getElementById("years")
    var year = parseInt(years.value);


    var vegeredmeny = function(amount,year,kamat) {
        var kamatvege = (kamat/100)+1;
        return (amount*Math.pow(kamatvege,year)).toFixed(2);
        }
    
    alert ("5 év múlva ennyi pénzed lesz: "+  vegeredmeny (amount,year,kamat  )+ "Ft");
}