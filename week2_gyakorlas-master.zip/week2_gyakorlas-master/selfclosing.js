function Helloka(){
    alert('Szia Bala');
}

