function rajzolj(){
    
    var oszlopokSzama=(document.getElementById("oszlop"));
    var oszlopok=oszlopokSzama.value;

    var sorokSzama=(document.getElementById("sor"));
    var sorok=sorokSzama.value;
    
    var body = document.body;
    var tbl = document.createElement('table');

    var szamlalo = 1;
    var tr,td;
    for(var i=0; i < sorok; i++){
         tr = tbl.insertRow();
        for (j =0;j<oszlopok;j++){
            td = tr.insertCell();
            td.appendChild(document.createTextNode(szamlalo));
            szamlalo=szamlalo+1;
        }
    }
    body.appendChild(tbl);
}
