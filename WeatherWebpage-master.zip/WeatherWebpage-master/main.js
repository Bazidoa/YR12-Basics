
   // var degree=Math.round(Math.random()*20);
   // query selector egy listát ad vissza, az összes spannal ami az oldalon van
    var spanlist = document.querySelectorAll('span.training_num');
    for ( var i=0;i<spanlist.length;i++){
        var degree=Math.round(Math.random()*20);
      spanlist[i].innerHTML = degree + "&degC";  
    }

/* Egészítsd ki az időjárás-jelentés oldalt a sokéves átlagtól való hőmérséklet eltérés megjelenítésével! 
Egy változóban tárold a budapesti sokéves átlaghőmérsékletet! 
Egy változóba számold ki a mai hőmérsékletnek az átlagtól való eltérését! Jelenítsd meg az értékeket az oldalon! A megjelenítéshez használhatod a következőhöz hasonló kódot (most még nem kell ezt ismerned, de a későbbiekben lesz szó róla részletesen):
document.querySelector('span.number_highlighted').innerHTML = degree;
*/

  var bpAtlagHom = 16;
  var maiElteres = bpAtlagHom - parseInt(spanlist[0].innerHTML);
  document.querySelector('span.number_highlighted').innerHTML = maiElteres;