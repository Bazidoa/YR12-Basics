"use strict";

function Adder(a,b){
    return a+b;
}

function Pythagoras(a,b){
    return a*a+b*b;
}

function Faktorialis(n){
    var result;

   if (n===1){
       result = 1;
   } else {
       result = n * Faktorialis(n-1);
   }

    return result;
}

function Faktorialis2(n){
    var eredmeny = 1;
    for (var i = n; i>0; i--){
        eredmeny = eredmeny*i;
    }
    return eredmeny;
}

function OnClickAttribute(sender){
    var proba=event.target;
    console.warn(sender);
    console.error(proba);
}

var nodeH2 = document.querySelector('H2');
nodeH2.onclick=OnClickProperty; //egy dolgot lehet rátenni egy elemre, 'On' valamiből. Az első functionben levő dolgokat nem írja ki.
nodeH2.addEventListener('click',Listener1,false);
nodeH2.addEventListener('click',Listener2,false);




function OnClickProperty(){
    console.log(event.target);
}

// eventlistener függvények NEM függhetnek másik eventlistenertől sem - nem lehetnek egymás feltételei mert nem látják egymást
function Listener1(){
    console.log('Handler1: ', event.target);
}
    
function Listener2(){  
    console.log('Handler2: ', event.target);  
    
}
var tomb = [1,2,3,4,5];
function tombRendezo (tomb){

for (var i = 0; i < tomb.length-1; i++){
    for ( var j = i+1;j<tomb.length; j ++){
        if (tomb[i] < tomb[j]){
            var temp = tomb[i];
            tomb[i] = tomb[j];
            tomb[j] = temp;
        }
    }
}
return tomb;
}

var tombteszt = ["elemer", "kristof", "szeptember"];

function arrayE (tomb){
    var ArrayE = [];
    for (var i = 0; i<tomb.length; i++){
        if (tomb[i].indexOf("e")!=-1){
            ArrayE.push(tomb[i]);
        }
    }return ArrayE;
}

var tombTeszt2 = [1,3,5,11,65,34,7,1000];

function ArrayDesc(tomb){
    for (var i = 0; i<tomb.length-1; i++){
        for (var j = i+1; j<tomb.length;j++){
            if (tomb[i]<tomb[j]){
                var temp = [tomb[i]];
                tomb[i] = tomb[j];
                tomb[j] = temp[0];
            }
        }
    } return tomb;
}