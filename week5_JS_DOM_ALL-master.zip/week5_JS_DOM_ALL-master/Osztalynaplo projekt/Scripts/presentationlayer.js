"use strict";

window.addEventListener("load",window_load_handler,false);

function window_load_handler(){
    var nodeForm = document.querySelector("FORM"); // kiszedjük a sumbit button elküldési funckióját
    nodeForm.addEventListener("submit",Form_Submit_Handler,false);
    console.log("You can start messing around in the DOM tree mate");
}

DrawEredmenyekJSON();
DrawRawsFromEredmenyek(Eredmenyek);

var nameAzBtn = document.querySelector("#nameAZBtn");
nameAzBtn.addEventListener("click",AzBtn_handler,false);

var nameZaBtn = document.querySelector("#nameZABtn")
nameZaBtn.addEventListener("click", ZaBtn_handler,false);


var nameAzBtn = document.querySelector("#subjAZBtn");
nameAzBtn.addEventListener("click",AzBtn_handler,false);

var nameZaBtn = document.querySelector("#subjZABtn")
nameZaBtn.addEventListener("click", ZaBtn_handler,false);

var nameAzBtn = document.querySelector("#markAZBtn");
nameAzBtn.addEventListener("click",AzBtn_handler,false);

var nameZaBtn = document.querySelector("#markZABtn")
nameZaBtn.addEventListener("click", ZaBtn_handler,false);

var nameAzBtn = document.querySelector("#dateAZBtn");
nameAzBtn.addEventListener("click",AzBtn_handler,false);

var nameZaBtn = document.querySelector("#dateZABtn")
nameZaBtn.addEventListener("click", ZaBtn_handler,false);


function AzBtn_handler(){
    var paramtoSortby= event.target.value;
    console.log(paramtoSortby);
    AscbyParam(paramtoSortby);
    DrawRawsFromEredmenyek(Eredmenyek);
    
}

function ZaBtn_handler(){
    var paramtoSortby= event.target.value;
    console.log(paramtoSortby);
    DescbyParam(paramtoSortby);
    DrawRawsFromEredmenyek(Eredmenyek);
}

function Form_Submit_Handler(){
    event.preventDefault(); //a default működését megakadályozza, tehát a submit most nem küldi el az adatot, de validál
    
    var nodeofNameInput = document.querySelector("#newName").value;
    var nodeofSubjectInput = document.querySelector("#newSubject").value;
    var nodeofMarkInput = document.querySelector("#newMark").value;
    var nodeofDateInput = document.querySelector("#newDate").value;

    var newObject = new Eredmeny (
        nodeofNameInput,nodeofSubjectInput,nodeofMarkInput,nodeofDateInput
    )

    Eredmenyek.push(newObject);

    //SavetoData();
    DrawEredmenyekJSON();
    DrawRawsFromEredmenyek(Eredmenyek);
    
}

function DrawEredmenyekJSON(){
    var divtodrawinto = document.querySelector("#JSON_Database");
    divtodrawinto.innerText = JSON.stringify(Eredmenyek,null,40);
}

function DrawRawsFromEredmenyek(eredmenyekarray){
    EmptyNaploTable();
    var NaploTableBody = document.querySelector("#NaploTableBody");
    for (var i = 0; i<eredmenyekarray.length; i++){
        var newTr = document.createElement("TR");
        for (var j = 0; j < Object.keys(eredmenyekarray[i]).length;j++){
            var newTD = document.createElement("TD");
            var InnerText = Object.values(eredmenyekarray[i])[j];
            newTD.innerText = InnerText;
            newTr.appendChild(newTD);
        }NaploTableBody.appendChild(newTr);
    }
}

function EmptyNaploTable(){
    var NaploTableBody = document.querySelector("#NaploTableBody");
    while (NaploTableBody.firstChild){
       NaploTableBody.removeChild(NaploTableBody.firstChild);
    }
}