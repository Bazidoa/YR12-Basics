"use strict";

var Eredmenyek = [];

LoadFromData();
AnonnymObjectToEredmeny(Eredmenyek);
console.log("Eredmenyek after mapping");
console.log(Eredmenyek);


function LoadFromData(){
    //olvassa be a json-t > parse = pl. eredmenyekarray
    var temp = [];
    temp = JSON.parse(jsonDatastore);
    console.log("Eredmenyek after parse from fakedatastore");
    console.log(temp);
    Eredmenyek=temp.map(AnonnymObjectToEredmeny); //létrehoztam a map transzormáció szabályát lent, akkor azt most rá kell engedni a tömbre mintha beépített metódus lenne

}

function AnonnymObjectToEredmeny(item,index,origArray){
    return new Eredmeny (item.Name, item.Subject, item.Mark, item.Date);
}


function AscbyParam(parameter){
    for (var i=0; i<Eredmenyek.length-1; i++){
        for (var j=i+1; j<Eredmenyek.length;j++){
            if (Eredmenyek[i][parameter]>Eredmenyek[j][parameter]){
                var temp = [Eredmenyek[i]];
                Eredmenyek[i] = Eredmenyek[j];
                Eredmenyek[j] = temp[0];
                console.warn(Eredmenyek);
            }
        }
    }
    console.log(Eredmenyek);
}

function DescbyParam(parameter){
    for (var i=0; i<Eredmenyek.length-1; i++){
        for (var j=i+1; j<Eredmenyek.length;j++){
            if (Eredmenyek[i][parameter]<Eredmenyek[j][parameter]){
                var temp = [Eredmenyek[i]];
                Eredmenyek[i] = Eredmenyek[j];
                Eredmenyek[j] = temp[0];
                console.warn(Eredmenyek);
            }
        }
    }
    return Eredmenyek;
}


function SavetoData(){
//ez most nem kell
}


function LoadNewEredmeny(){
    //save new Eredmeny from inputs as an Object of Eredmenyek
    //ezt a sumbit handlerben kezeltem
}

function PushNewEredmenytoEredmenyek(eredmenyObject){
    //just push the gotten eredmenyObject to Eredmenyek[]
    //csak simán bepusholtuk a prez layer sumbit gomb handler végén
}












function DataStoreInit(){
    //ez többet nem fog kelleni
Eredmenyek.push( new Eredmeny("Imi","Math",3,"2019-02-23"));
Eredmenyek.push( new Eredmeny("Bob","Biology",5,"2019-02-26"));
Eredmenyek.push( new Eredmeny("Jason","Chemistry",4,"2019-02-21"));
Eredmenyek.push( new Eredmeny("Claire","History",2,"2019-02-19"));

console.log(Eredmenyek);

var myJson = JSON.stringify(Eredmenyek);
console.log(myJson);

}
