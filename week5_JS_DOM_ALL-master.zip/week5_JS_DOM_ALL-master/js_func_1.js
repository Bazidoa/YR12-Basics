// Felhasználók listájának generálása.
var Gamers = [];
var names = ["Ramirez", "Gonsales", "Juan", "Juanita", "Jose", "Maria", "Ernesto","Éva"];
var skills = ['BF4', 'CS', 'CS-Go', 'PUBG', 'COD4', 'BF4'];

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

for (let i = 0; i < 100; i++) {
    var gamer = {};
    gamer.name = names[Math.floor(Math.random()*names.length)];
    gamer.skills = shuffle(skills).slice(0, Math.floor(Math.random()*skills.length));
    gamer.age = Math.floor(Math.random()*10) + 16;
    gamer.point = Math.round(Math.random()*500) + 50;    
    Gamers.push(gamer);
}

// Statisztika készítése.
function stat(gamers) {
    return {
        sumOfPoints: sumOfPoints(gamers),
        last: getFirstGamer(gamers),
        mostSkilled: getMostSkilledGamer(gamers),
        gamers: sortGamersByName(gamers)
    };
}

// TODO: készítsd el a négy hiányzó függvényt a 26-29 sorból.
// A függvények neve elárulja hogy mit kell végezniük.

function sumOfPoints(gamers){
    var sumOfPoints = 0;
    for (var i=0; i<gamers.length; i++){
        sumOfPoints += gamers[i].point;
    }
    console.log("sumOfPoints:");
    console.log(sumOfPoints);
    return sumOfPoints;
}

function getFirstGamer(gamers){
    var firstGamer = gamers[0];

    for (var i = 1; i<gamers.length; i++){
        if (firstGamer.point < gamers[i].point){
            firstGamer = gamers[i];
            console.log(firstGamer);
        }
    }

    console.log("firstGamer:");
    console.log(firstGamer);
    return firstGamer;
}

function getMostSkilledGamer(gamers){
    var mostSkilledGamer = gamers[0];
    for (var i = 1; i<gamers.length; i++){
        if (mostSkilledGamer.skills.length < gamers[i].skills.length){
            mostSkilledGamer = gamers[i];
            console.log(mostSkilledGamer);
        }
    }

    console.log("mostSkilledGamer");
    console.log(mostSkilledGamer);
    return mostSkilledGamer;
}

function sortGamersByName(gamers){

    for (i = 0; i<gamers.length-1; i++){
        for (j = i+1;j < gamers.length; j++){
         //   if ( gamers[i].name > gamers[j].name){
            if ( gamers[i].name.localeCompare(gamers[j].name) > 0){ 
                /*localeCompare összehasonlítja a megadott két Stringet ha az első "hamarabb jön" 
                ergó kisebb akk negatív eredményt ad, ha később jön ergó nagyobb akkor pozitív eredményt ad*/
                var temp = [gamers[i]];
                gamers[i] = gamers[j];
                gamers[j] = temp[0];
            }
        }
    }

    console.log(gamers);
}

stat(Gamers);




//////////////////////////Lássuk csak lecke gyakorlata : ///////////////////

function getTopGamer(gamers){
	var topGamer = gamers[0];
  	if (gamers.length == 0){
    	return null;
    }
		for (var i = 0; i<gamers.length; i++){
    		if (topGamer.points < gamers[i].points){
            	topGamer = gamers[i];		
            }
        } return topGamer;
}

function getHunGamers(gamers){
    var hunGamers = [];

    for (var i = 0; i<gamers.length;i++){
        if (gamers[i].country == 'HU'){
            hunGamers.push(gamers[i]);
        }
    }
return hunGamers.length;
}

function getSumOfPoints(gamers){
    window.sumPoints = 0;
    for (var i = 0; i<gamers.length; i++){
        window.sumPoints += gamers[i].points;
    }
 // alert (window.sumPoints);
    return window.sumPoints;
}

function getAvgOfPoints(gamers){
    return Math.floor(window.sumPoints / gamers.length);
}

////////////////// gyakorló DOM element bővítése ///////////////////

Element.prototype.colorMe = function (){
    if (this.innerText === "Goalkeeper" ){
       this.parentNode.setAttribute("style", "background-color: red");
   }
    if (this.innerText === "Defender" ){
       this.parentNode.setAttribute("style", "background-color: white");
   }
     if (this.innerText === "Midfielder" ){
       this.parentNode.setAttribute("style", "background-color: green");
   }
     if (this.innerText === "Forward" ){
       this.parentNode.setAttribute("style", "background-color: purple");
   }
   }


Element.prototype.pirosHatter = function (){
    this.style.backgroundColor = "green";
    };


    /////////////////////// DOM html gyakorló /////////////////////
    function sendForm() {
        //Ide dolgozz!
       var name = document.querySelector("#username");
       var pw = document.querySelector("#password");
       var result = document.querySelector("#result");
       
       if (name.value == "Bob" && pw.value == "password"){
           result.innerHTML = "Sikeres bejelentkezés!";
       } else {
           name.value = "";
             pw.value="";
             result.innerHTML = "Rossz felhasználónév vagy jelszó";
       }
       }