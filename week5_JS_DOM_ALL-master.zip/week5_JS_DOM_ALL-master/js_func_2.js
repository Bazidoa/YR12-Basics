// Felhasználók listájának generálása.
var Gamers = [];
var names = ["Ramirez", "Gonsales", "Juan", "Juanita", "Jose", "Maria", "Ernesto"];
var skills = ['BF4', 'CS', 'CS-Go', 'PUBG', 'COD4', 'BF4'];


function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

for (let i = 0; i < 100; i++) {
    var gamer = {};
    gamer.name = names[Math.floor(Math.random() * names.length)];
    gamer.skills = shuffle(skills).slice(0, Math.floor(Math.random() * skills.length));
    gamer.age = Math.floor(Math.random() * 10) + 16;
    gamer.point = Math.round(Math.random() * 500) + 50;
    Gamers.push(gamer);
}

console.log(Gamers);
getAvgPoint(Gamers);

/**
 * TODO: egészítsd ki az alábbi JAVASCRIPT függvényt, amely a kapott Gamers 
 * tömbben minden játékos skilljeihez hozzáadja az alábbi kettőt:
 * 'Super Mario', 'Mortal Combat'.
 * @param {*} gamers a játékosok tömbje.
 * DONE
 */
function addSkills(gamers) {

    for (let i = 0; i < gamers.length; i++) {
        Gamers[i].skills.push('Super Mario', "Mortal Kombat");
    }

}

/**
  * TODO: egészítsd ki az alábbi JAVASCRIPT függvényt, amely a kapott Gamers 
  * tömböt bejárja és visszaadja az összes játékos pontjainak az átlagát.
  * @param {*} gamers a játékosok tömbje.
  */


function getAvgPoint(gamers) {
    var PontokOsszege = 0;
    var AveragePoint = 0;
    for (let i = 0; i < gamers.length; i++) {
        PontokOsszege = gamers[i].point + PontokOsszege;
    }
    AveragePoint = PontokOsszege / Gamers.length;
    return AveragePoint;
}

/**
 * TODO: egészítsd ki az alábbi JAVASCRIPT függvényt, amely a kapott Gamers 
 * tömbben minden játékos objektumát bővíti egy új tulajdonsággal.
 * kulcs: topGamer
 * érték: akkor true, ha a pontja több mint getAvgPoint által visszaadott érték,
 * különben false.
 * @param {*} gamers a játékosok tömbje.
 */
function setTopGamers(gamers) {
    var atlagszam = getAvgPoint(gamers);
    for (var i = 0; i < gamers.length; i++) {
        gamers[i].topGamer = false;
        if (gamers[i].point > atlagszam) {
            gamers[i].topGamer = true;
        }
    }
}

/**
 * Játékosok ellenőrzése.
 * @param {*} gamers a játékosok tömbje.
 */
(function processGamers(gamers) {
    addSkills(gamers);
    setTopGamers(gamers);

})(Gamers);

console.log(Gamers);
