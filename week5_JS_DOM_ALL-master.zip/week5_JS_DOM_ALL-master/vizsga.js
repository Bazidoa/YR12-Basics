var x = 10;
function add(x) {
    x += 10;
    return x;
}
console.log(add(x));
console.log(x);
//a külső X-et nem változtatom, mert a functionban felüldifiniálom az X -et és ahhoz adok hozzá 10-et, a végén a második X logot az eredeti X-re hívom.


