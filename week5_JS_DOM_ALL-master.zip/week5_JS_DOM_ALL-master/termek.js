'use strict';

function Termek(termekID,category,megnevezes,egysegAr,fotoURL){
    this.TermekID = termekID;
    this.Category = category;
    this.Megnevezes = megnevezes;
    this.EgysegAr = egysegAr;
    this.FotoURL = fotoURL;
    this.DuplazzukAzArat=function(){ //tagfüggvény ~method
    this.EgysegAr = 2*this.egysegAr;

    }

    //return result -> a függvény visszatérése, max 1 min 0, típus deklarációnak nincs vissztérése
}


/*
var objTermek (){
    TermekID : 'id',
    Megnevezes: 'megnevezes',
    .
    .
    .

Anonim objektum, tökéletesen megfelel Objektum rögzítésére, ha később nem akarok instanceof-olni
}*/
