"use strict"

var cicak = [
    {name : 'Ketteske',age : 2 },
    { name : 'Egyeske', age : 1 },
    {name : 'Negyeske',age : 4 },
    {name : 'Harmaska',age : 3 },
    {name : 'Otoske',age : 5 },
    {name : 'Ketteske2',age : 2 }
]

/*Maximum keresés*/

function maximumKereses (){
var maximum = cicak[0].age;

for (var i = 0; i<cicak.length; i ++){
    if(cicak[i].age > maximum){
        maximum = cicak[i].age;
    }
    
}
//console.log(maximum);
return maximum;

}

// keresesi feltétel  elem indexének visszaadása
function IndexOf(aKeresettEletkor){
    var resultIndexOf = -1;

    for (var i =0; i<cicak.length; i++){
        if (cicak[i].age === aKeresettEletkor)
        {
            resultIndexOf = i;
            break;
        }
    }
    return resultIndexOf;
}

// keresési feltételnek megfelelő elem visszadaása
function SearchItem (aKeresettEletkor){
    var result = null; // nem létező objektumot adunk vissza

    for (var i =0; i<cicak.length; i++){
        if (cicak[i].age === aKeresettEletkor)
        {
            result =cicak[i];
            break;
        }
    }
    return result;
}

// keresési feltételnek megfelelő elemEK visszadaása
function FilterItems (aKeresettEletkor){
    var result = []; 

    for (var i =0; i<cicak.length; i++){
        if (cicak[i].age === aKeresettEletkor)
        {
            result.push(cicak[i]);
        }
    }
    return result;
}

//rendezési algoritmusok

function BuborekRendezes(){
 var temp = [];

 for (var i = 0; i<cicak.length-1; i++){
     for (var j = i+1; j<cicak.length; j++){
        
         if (cicak[i].age > cicak[j].age ){
         //console.error("LÉPÉSENKÉNT");
        // console.error(cicak[i]);
        // console.error(cicak[j]);

         temp.push(cicak[i]);
       //  console.error("ez van a tempben:")
        // console.error(temp)

         cicak[i] = cicak[j];
       //  console.error()
       //  console.error(cicak[i]);
         cicak[j] = temp[0];
         console.warn(cicak);
         temp=[];
         }
     }
 }
return cicak;
}


function Sum(){
var osszeg= 0;
for (var i = 0; i<arguments.length; i++){

    osszeg+=arguments[i];
}
return osszeg;
}

function empty_arg (){
    return arguments;
}

function concat(){
   var szoveg ="";
for (var i = 0; i<arguments.length;i++){

        szoveg += " " + arguments[i];
}return szoveg.trim(); // tabot szóközt eltávolítja
}