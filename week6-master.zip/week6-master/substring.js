"use strict";

var string = '"alma","körte","banán","szilva","citrom","cseresznye"';

var sliceolt = string.slice(-25,-20); // mettől meddig, csak lehet negatív is
console.log("sliceolt", sliceolt);


var substringelt = string.substring(5,10); // mettől meddig adja meg
console.log("substringelt", substringelt);

var substrelt = string.substr(5,10); // mettől mennyit adjon meg
console.log("substrelt", substrelt);