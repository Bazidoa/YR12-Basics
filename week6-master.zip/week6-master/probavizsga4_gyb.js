/*
1. Rendezési algoritumus, számok tömbje, NÖVEKVŐ SORRENDBEN
2. függvény kap tömböt, MINUMUM SZÁMTÁS, azt visszaadja
3. függvény bemenete Stringekből álló tömb, saját indexOf, adja vissza az első olyan string pozícióját amiben van e betű
4. számok tömbjét kap, visszaadja a páros számokat visszaadja egy út tömbben
*/
'use strict';

var arr = [2,3,4,5,6,7,10,33,11,7,20,56,88,12,2];

// Rendezési algoritumus, számok tömbje, NÖVEKVŐ SORRENDBEN
function AscArray(tomb){
    for (var i = 0; i<tomb.length-1;i++){
        for (var j = i+1; j<tomb.length; j++){
            if (tomb[i]>tomb[j]){
                var temp = [tomb[i]];
                tomb[i] = tomb[j];
                tomb[j]=temp[0];
            }
        }
    } return tomb;
}


// függvény kap tömböt, MINUMUM SZÁMTÁS, azt visszaadja

function findMininum (tomb){
    var min = tomb[0];
    for (var i = 1; i<tomb.length; i++){
        if (min > tomb[i]){
            min = tomb[i];
        }
    } return min;
}

//függvény bemenete Stringekből álló tömb, saját indexOf, adja vissza az első olyan string pozícióját amiben van e betű


var arr2 = ["EgrEs","alma","eper", "körte"];

function findEletter(tomb){
    var index = -1;
    for (var i=0;i<tomb.length;i++){
        if (tomb[i].toLowerCase().indexOf("e")>-1){
            // index = tomb.indexOf(tomb[i]);
            index = i;
            return index;
        }
    }
}

function findEletter2(tomb){
    var index = -1;
    for (var i=0;i<tomb.length;i++){
        if (tomb[i].indexOf("e")>-1){
            // index = tomb.indexOf(tomb[i]);
            index = i;
            return index;
        }
    }
}

var numbers = [1,2,3,4,5,6];
var newNumbers = numbers.filter(function(number){     return (number % 2 !== 0);  }).map(function(number){     return number * 2;
});

//számok tömbjét kap, visszaadja a páros számokat egy út tömbben

function findEvens (tomb){
    var evenArray = [];
    for (var i = 0; i<tomb.length; i++){
        if (tomb[i]%2==0){
            evenArray.push(tomb[i]);
        }
    }return evenArray;
}


//Keverő algoritmus

var arr3 = [1,2,3,4,5,6,7,8,9,10,11,12,13];

function shuffle(arr){
  var itemCount = arr.length;
  var index = 0;
  var result = [ ];

  while(result.length < itemCount){
    index = Math.floor(arr.length*Math.random());
    result.push(arr.splice(index,1)[0]);
  }
  return result;
}