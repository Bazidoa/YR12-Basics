"use strict";
var currentDate = new Date();
var dateObject = {
    time: currentDate.getTime(), //linux timestamp-et adja meg, javascript végére fűzz ezredet, 3 érték
    year: currentDate.getFullYear(),
    month: currentDate.getMonth() + 1, // a hónapok egy tömbben vannak elmentve, ezért január = 0, plusz egy kell ha a sorszáma kell
    day: currentDate.getDate(),
    hour: currentDate.getHours(),
    minutes: currentDate.getMinutes(),
    seconds: currentDate.getSeconds()
};




// SQL dátum formátum 2019-02-28 13:33:59 hónapnak kettő számjegyűnek kell lennie

//@showTime boolean, true -> kiírja az időt is, null-> csak ÉÉÉÉ-HH-NN

Date.prototype.sql = function(showTime){
    var date = [
        this.getFullYear(),
        addZero((this.getMonth()+1)),
        addZero(this.getDate()),
    ];

    var nap = [
        szovegesNap(this.getDay())
    ]
   
    var time = [
        addZero(this.getHours()),
        addZero(this.getMinutes()),
        addZero(this.getSeconds())
    ];
    
    if (!showTime){
        return [date.join('-'), 
     nap].join(" ");
    }

    function addZero(num){
        return num < 10 ? "0"+num : num;  //ha igaz akkor : előtti rész, ha hamis, kettőspont utáni rész
    }

    function szovegesNap(day){
        switch (day){
            case 1:
                return "Hétfő";
                break;
            case 2: 
                return "Kedd";
                break;
            case 3:
                return "Szerda";
                break;
            case 4:
                return "Csütörtök";
                break;
            case 5:
                return "Péntek";
                break;
            case 6:
                return "Szombat";
                break;
            case 7:
                return "Vasárnap";
                break;

        }
    }


    return [
        date.join('-'),
        nap,
        time.join(":"),
    ].join(" ");
};





console.log(currentDate.sql());
console.log(currentDate.sql(true));

/*
var username = document.querySelector("#usernameinput");
var password = document.querySelector("#passwordinput");
*/

var form = document.querySelector("form");
var formChildren = form.children;
formChildren[1].style.display ="none";
console.log(formChildren);

form.querySelector("input").onchange = function(){
    formChildren[0].style.display = "none";
    formChildren[1].style.display = "block";

}