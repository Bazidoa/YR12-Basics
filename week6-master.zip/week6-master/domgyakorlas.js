"use strict";

window.addEventListener("load", window_load_handler, false);

function window_load_handler() {
    console.log("You can start messing around in the DOM tree mate");
    builder();
}

function builder() {

    var list = document.querySelector('#list');

    var HozzaadasGomb = document.querySelector("#addButton");
    HozzaadasGomb.addEventListener("click", HozaadasGombHandler, false);

    var DeleteBtn = document.querySelector("#removeButton");
    DeleteBtn.addEventListener("click", DeleteGombHandler, false);


    var Gamers = [
        'Tom',
        'Joe',
        'Marc',
        'Bence',
        'Peti',
        'Levi'
    ];

    Gamers.forEach(function (gamer) {
        var item = document.createElement('li');
        item.className = "probalist";
        item.innerHTML = gamer;
        list.appendChild(item);
    });

}
// Innen jössz te:

function HozaadasGombHandler() {
    var myInput = document.querySelector("#newName");
    var myInputvalue = myInput.value;
    //console.log(myInputvalue);

    if (myInputvalue == "") {
        return;
    }

    var newLi = document.createElement("LI");
    newLi.innerText = myInputvalue;
    list.appendChild(newLi);

    myInput.value = "";
}

function DeleteGombHandler() {

    var list = document.querySelector('#list');
    list.removeChild(list.lastChild);
}